KeyProse brand starter.

Included:
- logo.svg (wordmark)
- favicon.svg (browser icon)
- colors.css (brand colors)
- fonts.txt (font choices)

keyprose.com is the planned domain and is not configured here.
