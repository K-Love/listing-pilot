Replace these files with your brand assets.

Included:
- logo.svg (replace with your logo)
- colors.css (your brand colors)
- fonts.txt (your font choices)
